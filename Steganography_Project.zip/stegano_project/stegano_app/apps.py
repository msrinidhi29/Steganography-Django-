from django.apps import AppConfig


class SteganoAppConfig(AppConfig):
    name = 'stegano_app'
